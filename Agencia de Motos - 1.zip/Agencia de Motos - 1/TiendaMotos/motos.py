from flask import Flask, request, jsonify
from flask_cors import CORS
import mysql.connector
from mysql.connector import Error
import base64

app = Flask(__name__)
CORS(app)

def create_connection():
    try:
        connection = mysql.connector.connect(
            host='localhost',
            database='bd_tienda_moto_sucursal_1',
            user='root',
            password=''
        )
        if connection.is_connected():
            return connection
    except Error as e:
        print(f"Error: {e}")
        return None

@app.route('/motos', methods=['GET'])
def get_motos():
    connection = create_connection()
    if connection is None:
        return jsonify({'message': 'Error de conexión a la base de datos'}), 500

    try:
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT * FROM motos")
        motos = cursor.fetchall()
        for moto in motos:
            if 'imagen' in moto and isinstance(moto['imagen'], bytes):
                moto['imagen'] = base64.b64encode(moto['imagen']).decode('utf-8')
    except Error as e:
        return jsonify({'message': f'Error: {e}'}), 500
    finally:
        cursor.close()
        connection.close()

    return jsonify(motos), 200

@app.route('/motos/<int:id_moto>', methods=['GET'])
def get_moto_by_id(id_moto):
    connection = create_connection()
    if connection is None:
        return jsonify({'message': 'Error de conexión a la base de datos'}), 500

    try:
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT * FROM motos WHERE id_moto = %s", (id_moto,))
        moto = cursor.fetchone()
        if moto and 'imagen' in moto and isinstance(moto['imagen'], bytes):
            moto['imagen'] = base64.b64encode(moto['imagen']).decode('utf-8')
    except Error as e:
        return jsonify({'message': f'Error: {e}'}), 500
    finally:
        cursor.close()
        connection.close()

    if moto:
        return jsonify(moto), 200
    else:
        return jsonify({'message': 'Moto no encontrada'}), 404

@app.route('/motos', methods=['POST'])
def create_moto():
    data = request.get_json()
    connection = create_connection()
    if connection is None:
        return jsonify({'message': 'Error de conexión a la base de datos'}), 500

    try:
        cursor = connection.cursor()
        sql = """INSERT INTO motos (id_moto, modelo, marca, ano, precio, id_agencia, cantidad, imagen)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)"""
        values = (
            data['id_moto'], data['modelo'], data['marca'], data['ano'], data['precio'], data['id_agencia'], data['cantidad'],
            base64.b64decode(data['imagen']) if 'imagen' in data else None
        )
        cursor.execute(sql, values)
        connection.commit()
        moto_id = data['id_moto']
    except Error as e:
        if e.errno == 1062:
            return jsonify({'message': 'El ID ya está ocupado, ocupa otro ID para este producto'}), 400
        return jsonify({'message': f'Error: {e}'}), 500
    finally:
        cursor.close()
        connection.close()

    return jsonify({'message': 'Moto agregada correctamente'}), 201

@app.route('/motos/<int:id_moto>', methods=['PUT'])
def update_moto(id_moto):
    data = request.get_json()
    connection = create_connection()
    if connection is None:
        return jsonify({'message': 'Error de conexión a la base de datos'}), 500

    try:
        cursor = connection.cursor()
        imagen_data = base64.b64decode(data['imagen']) if 'imagen' in data and data['imagen'] else None

        sql = """UPDATE motos SET modelo = %s, marca = %s, ano = %s, precio = %s, id_agencia = %s, cantidad = %s, imagen = %s WHERE id_moto = %s"""
        values = (
            data['modelo'], data['marca'], data['ano'], data['precio'], data['id_agencia'], data['cantidad'], imagen_data, id_moto
        )
        cursor.execute(sql, values)
        connection.commit()
    except Error as e:
        return jsonify({'message': f'Error: {e}'}), 500
    finally:
        cursor.close()
        connection.close()

    return jsonify({'message': 'Moto actualizada correctamente'}), 200

@app.route('/motos/<int:id_moto>', methods=['DELETE'])
def delete_moto(id_moto):
    connection = create_connection()
    if connection is None:
        return jsonify({'message': 'Error de conexión a la base de datos'}), 500

    try:
        cursor = connection.cursor()
        cursor.execute("DELETE FROM motos WHERE id_moto = %s", (id_moto,))
        connection.commit()
    except Error as e:
        return jsonify({'message': f'Error: {e}'}), 500
    finally:
        cursor.close()
        connection.close()

    return jsonify({'message': 'Moto eliminada correctamente'}), 200
#--------------------------------------------------------------------------------------------------Esto es lo que agregue
# Nuevo endpoint de búsqueda
@app.route('/motos/search', methods=['GET'])
def search_motos():
    query = request.args.get('query')
    if not query:
        return jsonify({"error": "Query parameter is required"}), 400

    connection = create_connection()
    if connection is None:
        return jsonify({'message': 'Error de conexión a la base de datos'}), 500

    try:
        cursor = connection.cursor(dictionary=True)
        search_query = f"%{query}%"
        cursor.execute("SELECT * FROM motos WHERE modelo LIKE %s OR marca LIKE %s", (search_query, search_query))
        motos = cursor.fetchall()
        for moto in motos:
            if 'imagen' in moto and isinstance(moto['imagen'], bytes):
                moto['imagen'] = base64.b64encode(moto['imagen']).decode('utf-8')
    except Error as e:
        return jsonify({'message': f'Error: {e}'}), 500
    finally:
        cursor.close()
        connection.close()

    return jsonify(motos), 200

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
