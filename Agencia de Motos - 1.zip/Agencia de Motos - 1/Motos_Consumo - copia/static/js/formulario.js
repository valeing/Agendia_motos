document.addEventListener('DOMContentLoaded', function() {
    const params = new URLSearchParams(window.location.search);
    const id_moto = params.get('id_moto');
    const api_url = params.get('api_url');

    if (id_moto && api_url) {
        // Cargar los datos de la moto desde la sucursal correcta
        fetch(`${api_url}/${id_moto}`)
            .then(response => response.json())
            .then(data => {
                for (const key in data) {
                    const input = document.querySelector(`[name="${key}"]`);
                    if (input) {
                        if (key === 'imagen' && data[key]) {
                            // Saltar la configuración de la imagen directamente en el input
                            continue;
                        }
                        input.value = data[key];
                    }
                }
            })
            .catch(error => console.error('Error:', error));
    }

    document.getElementById('motoForm').addEventListener('submit', function(e) {
        e.preventDefault();

        const formData = new FormData(e.target);
        const formObject = Object.fromEntries(formData.entries());

        const fileInput = document.getElementById('imagen');
        const file = fileInput.files[0];

        if (file) {
            const reader = new FileReader();
            reader.onloadend = function() {
                formObject.imagen = reader.result.split(',')[1]; 
                sendFormData(formObject, id_moto, api_url);
            };
            reader.readAsDataURL(file);
        } else {
            sendFormData(formObject, id_moto, api_url);
        }
    });

    document.getElementById('deleteButton').addEventListener('click', function() {
        if (confirm('¿Estás seguro de que deseas eliminar esta moto?')) {
            fetch(`${api_url}/${id_moto}`, {
                method: 'DELETE'
            })
            .then(response => response.json())
            .then(result => {
                alert(result.message);
                window.location.href = 'inventario.html'; // Redirigir a la página de inventario después de la eliminación
            })
            .catch(error => console.error('Error:', error));
        }
    });

    function sendFormData(formObject, id_moto, api_url) {
        fetch(`${api_url}${id_moto ? '/' + id_moto : ''}`, {
            method: id_moto ? 'PUT' : 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(formObject)
        })
        .then(response => response.json())
        .then(data => {
            alert(data.message);
            if (data.message === 'Motocicleta agregada correctamente' || data.message === 'Motocicleta actualizada correctamente') {
                window.location.href = 'inventario.html';
            }
        })
        .catch(error => console.error('Error:', error));
    }
});
