$(document).ready(function() {
    // Mostrar el formulario cuando se haga clic en el botón "Crear Moto"
    $('#create-moto').click(function() {
        $('#form-container').fadeIn();
        $('.form-overlay').fadeIn();
        $('#search-container').fadeOut(); // Oculta la barra de búsqueda
    });

    // Cerrar el formulario cuando se haga clic en el botón de cerrar
    $('#form-close').click(function() {
        $('#form-container').fadeOut();
        $('.form-overlay').fadeOut();
        $('#search-container').fadeIn(); // Muestra la barra de búsqueda nuevamente
    });

    // También cerrar el formulario si se hace clic en la superposición (opcional)
    $('.form-overlay').click(function() {
        $('#form-container').fadeOut();
        $('.form-overlay').fadeOut();
        $('#search-container').fadeIn(); // Muestra la barra de búsqueda nuevamente
    });

    // Manejar la búsqueda de motos
    $('#search-bar').on('input', function() {
        const query = $(this).val();
        if (query.trim() === '') {
            $('#results-container').empty().hide(); // Borra y oculta resultados si está vacío
        } else {
            searchMotorcycles(query);
        }
    });

    const searchMotorcycles = async (query) => {
        try {
            const response = await fetch(`http://localhost:5000/motos/search?query=${query}`);
            if (!response.ok) {
                throw new Error('Error en la solicitud de búsqueda');
            }
            const motorcycles = await response.json();
            displayMotorcycles(motorcycles);
        } catch (error) {
            console.error('Error:', error);
        }
    };

    const displayMotorcycles = (motorcycles) => {
        const container = $('#results-container');
        container.empty();
        if (motorcycles.length > 0) {
            motorcycles.forEach(moto => {
                const motoItem = `
                    <li data-id="${moto.id}">${moto.modelo} - ${moto.marca}</li>
                `;
                container.append(motoItem);
            });
            container.show(); // Muestra la lista de resultados
        } else {
            container.hide(); // Oculta la lista si no hay resultados
        }
    };

    // Manejar clics en resultados
    $(document).on('click', '#results-container li', function() {
        const motoId = $(this).data('id');
        console.log(`Moto seleccionada: ${motoId}`);
        $('#search-bar').val($(this).text()); // Opcional: completar el input con el texto del resultado
        $('#results-container').hide(); // Oculta los resultados después de seleccionar uno
    });

    // Cargar todas las motos inicialmente
    searchMotorcycles('');
});
