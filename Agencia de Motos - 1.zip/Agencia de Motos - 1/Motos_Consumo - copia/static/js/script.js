$(document).ready(function() {
    var formContainer = $('#form-container');

    bindFormClick();

    function bindFormClick() {
        $('#create-moto').on('click', function(e) {
            e.preventDefault();
            toggleForm();
            $(this).off();
        });
    }

    $('#form-close, .form-overlay').click(function(e) {
        e.stopPropagation();
        e.preventDefault();
        toggleForm();
        bindFormClick();
    });

    function toggleForm() {
        $(formContainer).toggleClass('expand');
        $('#form-content').toggleClass('expand');
        $('body').toggleClass('show-form-overlay');
    }

    $('#create-moto-form').submit(function(e) {
        e.preventDefault();
        var form = $(this);
        form.find('.form-error').removeClass('form-error');
        var formError = false;

        form.find('.input').each(function() {
            if ($(this).val() === '') {
                $(this).addClass('form-error');
                $(this).select();
                formError = true;
                return false;
            }
        });

        if (!formError) {
            var formData = new FormData(this);
            var formObject = Object.fromEntries(formData.entries());

            var fileInput = $('#imagen')[0];
            var file = fileInput.files[0];

            if (file) {
                var reader = new FileReader();
                reader.onloadend = function() {
                    formObject.imagen = reader.result.split(',')[1];
                    sendFormData(formObject);
                };
                reader.readAsDataURL(file);
            } else {
                alert('Por favor, selecciona una imagen para el diseño.');
            }
        }
    });

    function sendFormData(formObject) {
        fetch('http://localhost:5000/motos', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(formObject)
        })
        .then(response => response.json())
        .then(data => {
            alert(data.message);
            if (data.message === 'Moto agregada correctamente') {
                window.location.href = 'inventario.html';
            }
        })
        .catch(error => console.error('Error:', error));
    }

    fetch('http://localhost:5000/motos')
        .then(response => response.json())
        .then(motos => {
            const motosContainer = document.getElementById('motos-container');
            motos.forEach(moto => {
                const motoCard = document.createElement('div');
                motoCard.classList.add('card');

                const img = document.createElement('img');
                img.src = `data:image/jpeg;base64,${moto.imagen}`;
                motoCard.appendChild(img);

                const model = document.createElement('h3');
                model.textContent = moto.modelo;
                motoCard.appendChild(model);

                const brand = document.createElement('p');
                brand.textContent = `Marca: ${moto.marca}`;
                motoCard.appendChild(brand);

                // Crear botón "Ver Moto"
                const viewButton = document.createElement('button');
                viewButton.textContent = 'Ver Moto';
                viewButton.classList.add('view-button');
                viewButton.onclick = function() {
                    window.location.href = `ver_moto.html?id=${moto.id}`;
                };
                motoCard.appendChild(viewButton);

                motosContainer.appendChild(motoCard);
            });
        })
        .catch(error => {
            console.error('Error:', error);
        });
});
