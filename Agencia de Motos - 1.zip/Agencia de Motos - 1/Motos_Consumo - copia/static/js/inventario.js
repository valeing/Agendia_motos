document.addEventListener('DOMContentLoaded', function() {
    cargarDatosSucursal();

    document.getElementById('sucursal-select').addEventListener('change', cargarDatosSucursal);
});

function cargarDatosSucursal() {
    const sucursal = document.getElementById('sucursal-select').value;
    let apiUrl;

    if (sucursal === 'api1') {
        apiUrl = 'http://172.16.1.163:5000/motos';
    } else if (sucursal === 'api2') {
        apiUrl = 'http://172.16.1.198:5000/motos';
    }

    fetch(apiUrl)
        .then(response => response.json())
        .then(data => {
            const tableBody = document.querySelector('#inventory-table tbody');
            tableBody.innerHTML = '';

            data.forEach(moto => {
                const row = document.createElement('tr');

                const keys = ['id_moto', 'modelo', 'marca', 'ano', 'precio', 'cantidad', 'id_agencia', 'imagen'];

                keys.forEach(key => {
                    const cell = document.createElement('td');
                    if (key === 'imagen' && moto[key]) {
                        const img = document.createElement('img');
                        img.src = 'data:image/jpeg;base64,' + moto[key];
                        img.alt = 'Imagen de la moto';
                        cell.appendChild(img);
                    } else {
                        cell.textContent = moto[key] !== null ? moto[key] : 'N/A';
                    }
                    row.appendChild(cell);
                });

                const actionsCell = document.createElement('td');

                const editButton = document.createElement('button');
                editButton.textContent = 'Editar';
                editButton.className = 'btn btn-edit';
                editButton.addEventListener('click', () => {
                    window.location.href = `formulario.html?id_moto=${moto.id_moto}&api_url=${apiUrl}`;
                });
                actionsCell.appendChild(editButton);

                const deleteButton = document.createElement('button');
                deleteButton.textContent = 'Eliminar';
                deleteButton.className = 'btn btn-delete';
                deleteButton.addEventListener('click', () => {
                    fetch(`${apiUrl}/${moto.id_moto}`, {
                        method: 'DELETE'
                    })
                    .then(response => response.json())
                    .then(result => {
                        alert(result.message);
                        row.remove();
                    })
                    .catch(error => console.error('Error:', error));
                });
                actionsCell.appendChild(deleteButton);

                row.appendChild(actionsCell);

                tableBody.appendChild(row);
            });
        })
        .catch(error => console.error('Error:', error));
}
